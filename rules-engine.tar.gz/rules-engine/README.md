# ⚙ RulesForge — Business Rules Engine

A Python-based **Business Rules Engine** that loads YAML rules and evaluates them
against input data via a REST API. **Change rules without touching code.**

## Quick Start

```bash
pip install -r requirements.txt

# Run standalone demo (no server needed)
python demo.py

# Start the API server + dashboard
python app.py
# → http://localhost:5000
```

## Project Structure

```
rules-engine/
├── app.py              # Flask REST API server
├── rules_engine.py     # Core engine (evaluator + executor)
├── demo.py             # CLI demo script
├── dashboard.html      # Interactive web dashboard
├── requirements.txt
└── rules/
    ├── insurance.yaml  # Insurance pricing rules
    ├── ecommerce.yaml  # E-commerce discount rules
    └── loans.yaml      # Loan eligibility rules
```

## YAML Rule Syntax

```yaml
ruleset:
  name: My Rules
  version: "1.0.0"
  priority_mode: all   # "all" or "first_match"

rules:
  - id: R001
    name: Senior Discount
    priority: 10        # Lower = higher priority (runs first)
    condition: "age > 60 and smoker == false"
    actions:
      - set: discount_percent
        value: 15
      - multiply: base_premium
        by: 0.90
      - append: tags
        value: "senior_discount"
      - log: "Discount applied for age {age}"
```

## Supported Conditions

```yaml
condition: "age > 60"
condition: "score >= 700 and income > 50000"
condition: "status == 'active' or tier == 'gold'"
condition: "smoker == false and bmi < 25"
condition: "not is_banned"
```

## Supported Actions

| Action | Description | Example |
|--------|-------------|---------|
| `set` | Set field to value | `set: eligible / value: true` |
| `multiply` | Multiply field by factor | `multiply: price / by: 1.25` |
| `add` | Add amount to field | `add: rate / by: 0.5` |
| `subtract` | Subtract from field | `subtract: rate / by: 1.0` |
| `divide` | Divide field by value | `divide: score / by: 10` |
| `append` | Append to list | `append: tags / value: "vip"` |
| `log` | Log message with interpolation | `log: "Score is {score}"` |

## REST API

```
GET  /api/rulesets                  List all rulesets
GET  /api/rulesets/{name}           Get ruleset detail + rules
GET  /api/rulesets/{name}/yaml      Get raw YAML
PUT  /api/rulesets/{name}/yaml      Update YAML (hot-reload!)
POST /api/evaluate/{name}           Evaluate rules
POST /api/evaluate/{name}/batch     Batch evaluate
GET  /api/health                    Health check
```

### Evaluate Example

```bash
curl -X POST http://localhost:5000/api/evaluate/insurance \
  -H "Content-Type: application/json" \
  -d '{"age": 65, "smoker": false, "bmi": 24, "accidents": 0, "base_premium": 400}'

# With full debug trace:
curl -X POST "http://localhost:5000/api/evaluate/insurance?debug=true" ...
```

### Hot-Reload Rules (No Restart!)

```bash
# Edit rules/insurance.yaml, then:
curl -X PUT http://localhost:5000/api/rulesets/insurance/yaml \
  --data-binary @rules/insurance.yaml
# → Rules update instantly
```

## Adding New Rulesets

Just create a new YAML file in the `rules/` directory:

```bash
cp rules/insurance.yaml rules/my_rules.yaml
# Edit my_rules.yaml...
# It's immediately available at /api/rulesets/my_rules
```

No code changes, no server restart.
